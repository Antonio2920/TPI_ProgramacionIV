// Evento al cambiar el curso
document.getElementById('cursoSelect').addEventListener('change', function () {
    const cursoSeleccionado = this.value;
    const alumnoSelect = document.getElementById('alumnoSelect');
    alumnoSelect.innerHTML = '<option value="">--Seleccionar--</option>';

    if (cursoSeleccionado) {
        fetch(`/api/alumnos/${cursoSeleccionado}`) // Corregido aquí
            .then(response => response.json())
            .then(alumnos => {
                alumnos.forEach(alumno => {
                    const option = document.createElement('option');
                    option.value = alumno.id;
                    option.textContent = alumno.nombre;
                    alumnoSelect.appendChild(option);
                });
                
                alumnoSelect.disabled = false;
            })
            .catch(error => {
                console.error('Error al cargar los alumnos:', error);
                alumnoSelect.disabled = true;
            });
    } else {
        alumnoSelect.disabled = true;
    }
});

// Evento al seleccionar el alumno
document.getElementById('alumnoSelect').addEventListener('change', async function () {
    const alumnoSeleccionado = this.value;
    const tablaNotasContainer = document.getElementById('tablaNotasContainer');
    const notasBody = document.getElementById('notasBody');

    if (alumnoSeleccionado) {
        tablaNotasContainer.style.display = 'block';

        // Obtiene las materias y las notas
        fetch('/api/materias')
            .then(response => response.json())
            .then(async materias => {
                notasBody.innerHTML = ''; // Limpia la tabla
                for (const materia of materias) {
                    const row = document.createElement('tr');

                    const cellMateria = document.createElement('td');
                    cellMateria.textContent = materia.NombreMateria;
                    cellMateria.setAttribute('data-id', materia.idmateria);
                    row.appendChild(cellMateria);

                    // Fetch para obtener las notas de la materia y alumno específico
                    const notasResponse = await fetch(`/api/notas/${alumnoSeleccionado}/${materia.idmateria}`); // Corregido aquí
                    const notasData = await notasResponse.json();
                    const notas = notasData.length > 0 ? notasData[0] : {};

                    // Crea las celdas de notas
                    for (let i = 1; i <= 10; i++) {
                        const cellNota = document.createElement('td');
                        const inputNota = document.createElement('input');
                        inputNota.type = 'number';
                        inputNota.min = '0';
                        inputNota.max = '10';
                        inputNota.placeholder = `Nota ${i}`; // Corregido aquí
                        inputNota.value = notas[`nota${i}`] || ''; // Corregido aquí
                        inputNota.setAttribute('data-field', `nota${i}`); // Corregido aquí
                        cellNota.appendChild(inputNota);
                        row.appendChild(cellNota);
                    }

                    notasBody.appendChild(row);
                }
            })
            .catch(error => {
                console.error('Error al cargar las materias o notas:', error);
            });
    } else {
        tablaNotasContainer.style.display = 'none';
    }
});

// Guardar notas al hacer clic en el botón
document.getElementById('btnGuardarNotas').addEventListener('click', async () => {
    const alumnoId = document.getElementById('alumnoSelect').value;
    if (!alumnoId) {
        alert("Selecciona un alumno antes de guardar las notas.");
        return;
    }

    const notas = [];
    const filas = document.querySelectorAll('#notasBody tr');

    filas.forEach(fila => {
        const materiaId = fila.querySelector('td[data-id]').getAttribute('data-id');
        const notaInputs = fila.querySelectorAll('input');

        const notaData = { Usuarios_idusuario: alumnoId, Materias_idmateria: materiaId };
        notaInputs.forEach(input => {
            const fieldName = input.getAttribute('data-field');
            notaData[fieldName] = input.value || null;
        });

        notas.push(notaData);
    });

    document.getElementById('btnGuardarNotas').disabled = true;
    try {
        const response = await fetch('/api/notas', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(notas)
        });

        if (!response.ok) {
            throw new Error('Error al guardar las notas');
        }

        const data = await response.json();
        alert(data.message || 'Notas actualizadas correctamente');
    } catch (error) {
        console.error('Error:', error);
        alert('Error al actualizar notas: ' + error.message);
    } finally {
        document.getElementById('btnGuardarNotas').disabled = false;
    }
});

const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const cors = require('cors');
const app = express();
const port = 3000;

// Configura el servidor para leer JSON
app.use(express.json());
app.use(cors({
    origin: 'http://localhost:3000', // Cambia esto por el dominio que necesites
    methods: ['GET', 'POST', 'PUT']
  }));

// Servir archivos estáticos desde el directorio 'html'
app.use(express.static(path.join(__dirname)));

// Configura la conexión a la base de datos
const cone = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: '338925antonio',
    database: 'mydb'
});

// Conexión a la base de datos
cone.connect((err) => {
    if (err) {
        console.error("Error al conectar:", err);
        return;
    }
    console.log("Conexión Exitosa");
});

// Ruta para agregar un nuevo usuario
app.post('/api/usuarios', (req, res) => {
    const { curso, nombre, username, password } = req.body;
    const query = "INSERT INTO usuarios (id_Cursodivision, NombreyApellido, Usuarios, Contraseña, Admin) VALUES (?, ?, ?, ?, 0)";
    const values = [curso, nombre, username, password];

    cone.query(query, values, (error, result) => {
        if (error) {
            return res.status(500).json({ error: "Error al insertar usuario" });
        }
        res.json({ message: "Alumno ingresado correctamente" });
    });
});

// Ruta para autenticar un usuario
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const query = "SELECT * FROM usuarios WHERE Usuarios = ? AND Contraseña = ?";

    cone.query(query, [username, password], (error, results) => {
        if (error) {
            return res.status(500).json({ error: "Error al verificar las credenciales" });
        }

        if (results.length > 0) {
            res.json({ success: true, role: results[0].Admin ? 'admin' : 'usuario' });
        } else {
            res.status(401).json({ success: false, message: "Credenciales incorrectas" });
        }
    });
});


app.get('/api/notas', (req, res) => {
    const query = "SELECT * FROM notas"; // Ajusta el nombre de la tabla según sea necesario

    cone.query(query, (error, result) => {
        if (error) {
            return res.status(500).json({ error: "Error al obtener las notas" });
        }

        res.json(result); // Enviar las notas como respuesta
    });
});

app.put('/api/notas', (req, res) => {
    const { Usuarios_idusuario, Materias_idmateria, ...notas } = req.body;

    // Construimos la consulta dinámicamente
    const campos = Object.keys(notas);
    const valores = Object.values(notas);

    // Si no hay campos de calificaciones para actualizar, devolvemos un error
    if (campos.length === 0) {
        return res.status(400).json({ error: "No se especificaron calificaciones para actualizar." });
    }

    // Creamos la parte SET de la consulta SQL
    const setClause = campos.map(campo => `${campo} = ?`).join(", ");
    
    const query = `
        UPDATE notas
        SET ${setClause}
        WHERE Usuarios_idusuario = ? AND Materias_idmateria = ?
    `;

    // Agregamos los IDs al final de los valores
    const valoresConIDs = [...valores, Usuarios_idusuario, Materias_idmateria];

    // Ejecutamos la consulta
    cone.query(query, valoresConIDs, (error, result) => {
        if (error) {
            console.error("Error al actualizar notas:", error);
            return res.status(500).json({ error: "Error al actualizar las notas" });
        }
        res.json({ message: "Notas actualizadas correctamente" });
    });
});



// Ruta para obtener alumnos de un curso específico
app.get('/api/alumnos/:curso', (req, res) => {
    const curso = req.params.curso;

    const query = "SELECT idusuario AS id, NombreyApellido AS nombre FROM usuarios WHERE id_Cursodivision = ?";
    cone.query(query, [curso], (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error en la base de datos' });
        }
        res.json(results);
    });
});

// Ruta para obtener las materias
app.get('/api/materias', (req, res) => {
    const query = "SELECT idmateria, NombreMateria FROM materias";

    cone.query(query, (error, results) => {
        if (error) {
            console.error("Error al obtener materias:", error);
            return res.status(500).json({ error: "Error al obtener materias" });
        }
        res.json(results);
    });
});

// Ruta para obtener notas de un alumno específico y una materia específica
app.get('/api/notas/:idusuario/:idmateria', (req, res) => {
    const { idusuario, idmateria } = req.params;  // Ahora obtiene los parámetros de la URL
    const query = "SELECT * FROM notas WHERE Usuarios_idusuario = ? AND Materias_idmateria = ?";

    cone.query(query, [idusuario, idmateria], (error, results) => {
        if (error) {
            console.error("Error al obtener notas:", error);
            return res.status(500).json({ error: "Error al obtener notas" });
        }
        
        if (results.length === 0) {
            return res.status(404).json({ message: "No se encontraron notas para el usuario y materia especificados." });
        }

        res.json(results);
    });
});



// Inicia el servidor
app.listen(port, () => {
    console.log(`Servidor corriendo en http://127.0.0.1:${port}`);
});
